package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@Accessors(chain = true, fluent = false) //chain为链式调用，fluent为流式调用(可以混合使用)
public class Page {
    private int page = 1;    //当前第几页
    private int rows = 20;   //每页显示记录数
    private int firstPage;  //第几条记录起始(datagrid)
    private int firstPimg;  //第几条记录起始(treegrid)

    public int getFirstPage() {
        firstPage = (page - 1) *  rows;
        return firstPage;
    }

    public int getFirstPimg() {
        firstPimg = (page - 1) * rows;
        return firstPimg;
    }
}
