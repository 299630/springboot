package com.example.demo.service;

import com.example.demo.model.User;

import java.util.List;

public interface UserService {
    int insert(User user);
    int delete(Integer id);
    int update(User user);
    Object getCount(User user);
    User getModel(Integer id);
    List<User> getList(User user);
    List<User> getPage(User user);
}
