package com.example.demo.serviceImpt;

import com.example.demo.mapper.TreeMapper;
import com.example.demo.model.Tree;
import com.example.demo.service.TreeService;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("treeService")
public class TreeServiceImpt implements TreeService {

    @Autowired
    TreeMapper mapper;

//    private JSONArray array = new JSONArray();
//    private JSONObject temp = new JSONObject();

    @Override
    public JSONArray dynamicTree2(Tree tree){
        JSONArray array = new JSONArray();
        JSONObject temp = new JSONObject();
        List<Tree> list = mapper.getParentId(tree.getParentId());
        if (list != null){
            for(Tree t :list){
                temp.put("id",t.getId());
                temp.put("name",t.getName());
                temp.put("parentId",t.getParentId());
                temp.put("description",t.getDescription());
                if (mapper.getParentId(t.getId()).size() > 0){
                    temp.put("state","closed");    //state=closed代表该分类下面有分类，state=open则没有
                }else {
                    temp.put("state","open");
                }
                array.add(temp);
            }
        }
        return array;
    }

    //同步加载的树
    public JSONArray getTree(Tree tree){
        JSONArray array = new JSONArray();
        JSONObject temp = new JSONObject();
        List<Tree> list = mapper.getList(tree);
        System.out.println(list.size());
        if (list.size() > 0){
            for(Tree t :list) {
                if (t.getParentId() == 0){      //只遍历顶级节点
                    temp.put("id", t.getId());
                    temp.put("name", t.getName());
                    temp.put("parentId", t.getParentId());
                    temp.put("description", t.getDescription());
                    putGridChild(temp, list, t.getId());
                    array.add(temp);
                }
            }
        }
        return array;
    }

    //递归生成树
    private void putGridChild(JSONObject obj, List<Tree> list, Integer parId){
        JSONArray array = new JSONArray();
        JSONObject temp = new JSONObject();
        for(Tree t :list){
            if(parId.equals(t.getParentId())){
                temp.put("id",t.getId());
                temp.put("name",t.getName());
                temp.put("parentId",t.getParentId());
                temp.put("description",t.getDescription());
                putGridChild(temp, list, t.getId());
                array.add(temp);
            }
        }
        if(array != null){
            obj.put("children",array);
        }
    }

    @Override
    public int insert(Tree tree) {
        return 0;
    }

    @Override
    public int delete(Integer id) {
        return mapper.delete(id);
    }

    @Override
    public int update(Tree tree) {
        return mapper.update(tree);
    }

    @Override
    public Object getCount(Tree tree) {
        return mapper.getCount(tree);
    }

    @Override
    public Tree getModel(Integer id) {
        return mapper.getModel(id);
    }

    @Override
    public List<Tree> getList(Tree tree) {
        return mapper.getList(tree);
    }

    @Override
    public List<Tree> getPage(Tree tree) {
        return mapper.getPage(tree);
    }

    @Override
    public List<Tree> getParentId(Integer parentId) {
        return mapper.getParentId(parentId);
    }
}
