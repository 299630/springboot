package com.example.demo.util;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;

import java.io.File;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

public class DataModel {
    public static void main(String[] args) throws IOException, TemplateException {

        /* 您应该在整个应用程序生命周期中执行此操作：       */

        /* 创建并调整配置单例 */
        Configuration cfg = new Configuration(Configuration.VERSION_2_3_22);
        cfg.setDirectoryForTemplateLoading(new File("D:/freemarker/")); //设置模板加载目录
        cfg.setDefaultEncoding("UTF-8"); //设置默认编码
        cfg.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER); //设置模板异常处理程序为RETHROW_HANDLER（重新抛出处理程序）

        /* ------------------------------------------------------------------------ */
        /* 您通常在应用程序生命周期中为MULTIPLE TIMES执行以下操作：   */

        /* 创建数据模型 */
        Map root = new HashMap();
        root.put("user", "Big Joe");
        Map latest = new HashMap();
        root.put("latestProduct", latest);
        latest.put("url", "products/greenmouse.html");
        latest.put("name", "绿色鼠标");

        /* 获取模板（在内部使用缓存） */
        Template temp = cfg.getTemplate("test.ftl");

        /* 将数据模型与模板合并 */
        Writer out = new OutputStreamWriter(System.out);
        temp.process(root, out);
        // 注意：根据`out`是什么，你可能需要调用`out.close（）`.
        // 这通常是文件输出的情况，但不适用于servlet输出.
    }
}
