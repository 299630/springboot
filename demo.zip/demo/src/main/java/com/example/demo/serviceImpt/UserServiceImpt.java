package com.example.demo.serviceImpt;

import com.example.demo.mapper.UserMapper;
import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("userService")
public class UserServiceImpt implements UserService {

    @Autowired
    UserMapper mapper;

    @Override
    public int insert(User user) {
        return mapper.insert(user);
    }

    @Override
    public int delete(Integer id) {
        return mapper.delete(id);
    }

    @Override
    public int update(User user) {
        return mapper.update(user);
    }

    @Override
    public Object getCount(User user) {
        return mapper.getCount(user);
    }

    @Override
    public User getModel(Integer id) {
        return mapper.getModel(id);
    }

    @Override
    public List<User> getList(User user) {
        return mapper.getList(user);
    }

    @Override
    public List<User> getPage(User user) {
        return mapper.getPage(user);
    }
}
