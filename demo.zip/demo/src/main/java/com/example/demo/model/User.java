package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

@Getter
@Setter
@ToString
@Accessors(chain = true, fluent = false)  //chain为链式调用，fluent为流式调用(可以混合使用)
public class User extends Page {
    private Integer id;
    private String code;
    private String pass;
    private String name;
    private Integer age;
    private Integer sex;
    private String sexName;

}
