package com.example.demo.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.experimental.Accessors;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Getter
@Setter
@ToString
@Accessors(chain = true, fluent = false) //chain为链式调用，fluent为流式调用(可以混合使用)
public class Tree extends Page {
    private Integer id;                 //id
    private String name;                //名称
    private Integer parentId;           //上级id
    private String description;         //说明
    //treegrid属性
    private String state;    //
//    private String children = "[]";
}
