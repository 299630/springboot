package com.example.demo.controller;

import com.example.demo.model.Tree;
import com.example.demo.service.TreeService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("tree")
public class TreeController {
    @Autowired
    TreeService service;

    @RequestMapping("")
    public String tree(){
        return "tree";
    }

    @RequestMapping( value = "getPage",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String selectModel(Tree tree){
        Map<String, Object> map = new HashMap<>();
        map.put("rows", service.getPage(tree));
        map.put("total", service.getCount(tree));
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "getList",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getList(Tree tree){
        Map<String, Object> map = new HashMap<>();
        map.put("rows", service.getList(tree));
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "getTree",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getTree(Tree tree) {
        Map<String, Object> map = new HashMap<>();
        map.put("rows", service.getTree(tree));
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "dynamicTree",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String dynamicTree(Tree tree) {
        Map<String, Object> map = new HashMap<>();
        List<Tree> list = service.getParentId(tree.getParentId());
        if (list.size() > 0){
            for (Tree t : list){
                if (service.getParentId(t.getId()).size() > 0){
                    t.setState("closed");
                }else {
                    t.setState("open");
                }
            }
        }
        map.put("rows",list);
        if (tree.getParentId() != 0){
            return new JSONArray(list).toString();
        }
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "dynamicTree2",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String dynamicTree2(Tree tree) {
        Map<String, Object> map = new HashMap<>();
        if (tree.getParentId() != 0){
            return new JSONArray(service.dynamicTree2(tree)).toString();
        }
        map.put("rows", service.dynamicTree2(tree));
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "getModel",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getModel(Tree tree){
        return new JSONObject(service.getModel(tree.getId())).toString();
    }

    @RequestMapping( value = "insert",produces = "application/json;charset=utf-8")
    public String insert(Tree tree){
        return  service.insert(tree)+"";
    }

    @RequestMapping( value = "delete",produces = "application/json;charset=utf-8")
    public String delete(Integer id){
        return service.delete(id)+"";
    }

    @RequestMapping( value = "update",produces = "application/json;charset=utf-8")
    public String update(Tree tree){
        return service.update(tree)+"";
    }
}
