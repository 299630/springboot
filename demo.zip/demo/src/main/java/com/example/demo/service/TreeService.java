package com.example.demo.service;

import com.example.demo.model.Tree;
import net.sf.json.JSONArray;

import java.util.List;

public interface TreeService {
    int insert(Tree tree);
    int delete(Integer id);
    int update(Tree tree);
    Object getCount(Tree tree);
    Tree getModel(Integer id);
    List<Tree> getList(Tree tree);
    List<Tree> getPage(Tree tree);
    List<Tree> getParentId(Integer parentId);
    JSONArray dynamicTree2(Tree tree);
    JSONArray getTree(Tree tree);
}
