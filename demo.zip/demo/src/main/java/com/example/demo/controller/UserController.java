package com.example.demo.controller;

import com.example.demo.model.User;
import com.example.demo.service.UserService;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("user")
public class UserController {

    @Autowired
    UserService service;

    @RequestMapping("")
    public String user(){
        return "user";
    }

    @RequestMapping( value = "getPage",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getPage(User user){
        Map<String, Object> map = new HashMap<>();
        map.put("rows", service.getPage(user));
        map.put("total", service.getCount(user));
        return new JSONObject(map).toString();
    }

    @RequestMapping( value = "getList",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getList(User user){
        return new JSONArray(service.getList(user)).toString();
    }

    @RequestMapping( value = "getModel",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String getModel(User user){
        return new JSONObject(service.getModel(user.getId())).toString();
    }

    @RequestMapping( value = "insert",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String insert(User user){
        return  service.insert(user)+"";
    }

    @RequestMapping( value = "delete",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String delete(User user){
        return service.delete(user.getId())+"";
    }

    @RequestMapping( value = "update",produces = "application/json;charset=utf-8")
    @ResponseBody
    public String update(User user){
        return service.update(user)+"";
    }

}
