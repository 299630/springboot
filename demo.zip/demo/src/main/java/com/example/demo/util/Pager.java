package com.example.demo.util;

public class Pager<T> {
    private int     page = 1;    //当前第几页
    private int     rows = 10;   //每页显示记录数
    private int     firstPage;  //第几条记录起始

    public int getPage() {
        return page;
    }

    public T setPage(int page) {
        this.page = page;
        return (T)this;
    }

    public int getRows() {
        return rows;
    }

    public  T setRows(int rows) {
        this.rows = rows;
        return (T)this;
    }

    public int getFirstPage() {
        firstPage = (page - 1) * rows;
        return firstPage;
    }

    public T setFirstPage(int firstPage) {
        this.firstPage = firstPage;
        return (T)this;
    }

}
